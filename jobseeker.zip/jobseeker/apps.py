from django.apps import AppConfig


class JobseekerConfig(AppConfig):
    name = 'jobseeker'
