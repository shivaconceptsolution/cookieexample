from django.shortcuts import render,redirect	
from django.http import HttpResponse
from .models import Reg
def index(request):
	if request.method=="POST":
		chkemail = Reg.objects.filter(email=request.POST["txtemail"])
		if chkemail.count()==0:
		 r = Reg(username=request.POST["txtuser"],password=request.POST["txtpass"],email=request.POST["txtemail"],mobile=request.POST["txtmobile"])
		 r.save()
		 return redirect('login')
		else:
			return render(request,"jobseeker/reg.html",{'key':'email already exist'})	 	

	return render(request,"jobseeker/reg.html")


def login(request):
	if request.COOKIES.get("ucookie"):
			request.session["uid"]=request.COOKIES["ucookie"]
			return redirect('/jobseeker/dashboard')

	elif request.method=="POST":
		r = Reg.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"])
		
		if r.count()>0:
		  response = HttpResponse(status=302)
		  response.set_cookie('ucookie',request.POST["txtuser"])
		  response.set_cookie('upass',request.POST["txtpass"])	
		  request.session["uid"]=request.POST["txtuser"]
		  response['Location'] = 'dashboard'
		  return response	
		  #return redirect('dashboard')
		else:
		  return render(request,"jobseeker/login.html",{'key':'Invalid userid and password'})  
    
	return render(request,"jobseeker/login.html")
	
def dashboard(request):
	if request.session.has_key('uid'):
	  s= request.session["uid"]
	  data = Reg.objects.filter(username=s)
	  return render(request,"jobseeker/dashboard.html",{'key':s,'res':data})
	else:
		return redirect('/jobseeker/login')
	  

def logout(request):
	del request.session["uid"]
	response = HttpResponse(status=302)
	response.delete_cookie('ucookie')
	response.delete_cookie('upass')
	response['Location'] = '/jobseeker/login'
	return response


def setCookie(request):
	response = HttpResponse("Cookie Set")
	response.set_cookie('ckey', 'hello')
	return response

def getCookie(request):
	a  = request.COOKIES['ckey']
	return HttpResponse("value is "+  a);    
