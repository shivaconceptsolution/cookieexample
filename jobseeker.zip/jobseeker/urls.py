from django.urls import path
from . import views

urlpatterns=[
path('',views.login,name='login'),
path('',views.index,name='index'),
path('login',views.login,name='login'),
path('dashboard',views.dashboard,name='dashboard'),
path('setCookie',views.setCookie,name='setCookie'),
path('getCookie',views.getCookie,name='getCookie'),
path('logout',views.logout,name='logout'),

]